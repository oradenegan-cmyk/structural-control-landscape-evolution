"""Record a matplotlib figure as native, editable Word (DrawingML) shapes.

A RendererAgg subclass is used so that all text metrics and layout are those of the
normal figure; draw calls are recorded as vector paths and text runs and then written
as a DrawingML group (wpg) of freeform shapes and text boxes.
"""
import math
from xml.sax.saxutils import escape
import numpy as np
from matplotlib.backends.backend_agg import RendererAgg
from matplotlib.backend_bases import RendererBase
from matplotlib.mathtext import MathTextParser
from matplotlib.path import Path

EMU = 12700.0
FONT = "Arial"
_MT = MathTextParser("path")


def _hex(c):
    return "%02X%02X%02X" % tuple(int(round(255 * v)) for v in c[:3])


def _clip_line(pts, bb):
    """Clip a polyline to bbox (x0,y0,x1,y1); returns list of polylines."""
    x0, y0, x1, y1 = bb
    out, cur = [], []
    def inside(p):
        return x0 <= p[0] <= x1 and y0 <= p[1] <= y1
    for i in range(len(pts) - 1):
        (ax, ay), (bx, by) = pts[i], pts[i + 1]
        dx, dy = bx - ax, by - ay
        t0, t1 = 0.0, 1.0
        ok = True
        for p, q in ((-dx, ax - x0), (dx, x1 - ax), (-dy, ay - y0), (dy, y1 - ay)):
            if p == 0:
                if q < 0:
                    ok = False; break
            else:
                t = q / p
                if p < 0:
                    if t > t1: ok = False; break
                    t0 = max(t0, t)
                else:
                    if t < t0: ok = False; break
                    t1 = min(t1, t)
        if not ok:
            if cur: out.append(cur); cur = []
            continue
        s = (ax + t0 * dx, ay + t0 * dy); e = (ax + t1 * dx, ay + t1 * dy)
        if not cur:
            cur = [s]
        elif cur[-1] != s:
            out.append(cur); cur = [s]
        cur.append(e)
        if t1 < 1.0:
            out.append(cur); cur = []
    if cur: out.append(cur)
    return [c for c in out if len(c) > 1]


def _clip_poly(pts, bb):
    x0, y0, x1, y1 = bb
    def clip(poly, inside, inter):
        if not poly: return poly
        res = []
        prev = poly[-1]
        for cur in poly:
            if inside(cur):
                if not inside(prev): res.append(inter(prev, cur))
                res.append(cur)
            elif inside(prev):
                res.append(inter(prev, cur))
            prev = cur
        return res
    def ix(xc):
        return lambda a, b: (xc, a[1] + (b[1] - a[1]) * (xc - a[0]) / (b[0] - a[0]))
    def iy(yc):
        return lambda a, b: (a[0] + (b[0] - a[0]) * (yc - a[1]) / (b[1] - a[1]), yc)
    p = list(pts)
    p = clip(p, lambda q: q[0] >= x0, ix(x0))
    p = clip(p, lambda q: q[0] <= x1, ix(x1))
    p = clip(p, lambda q: q[1] >= y0, iy(y0))
    p = clip(p, lambda q: q[1] <= y1, iy(y1))
    return p if len(p) > 2 else []


HATCH = {"/": "wdUpDiag", "\\": "wdDnDiag", ".": "pct40", "x": "diagCross", "-": "ltHorz", "|": "ltVert", "+": "cross"}


class ShapeRenderer(RendererAgg):
    # use the generic (path based) implementations so everything reaches draw_path
    draw_markers = RendererBase.draw_markers
    draw_path_collection = RendererBase.draw_path_collection
    draw_quad_mesh = RendererBase.draw_quad_mesh

    def __init__(self, w_pt, h_pt):
        super().__init__(int(math.ceil(w_pt)), int(math.ceil(h_pt)), 72)
        self.W, self.H = w_pt, h_pt
        self.items = []
        import functools
        for nm in ('draw_markers', 'draw_path_collection', 'draw_quad_mesh'):
            setattr(self, nm, functools.partial(getattr(RendererBase, nm), self))

    # ------------------------------------------------------------------ paths
    def draw_path(self, gc, path, transform, rgbFace=None):
        subs, closed = [], []
        cur = []
        for verts, code in path.iter_segments(transform, remove_nans=True, simplify=False, curves=False):
            if code == Path.MOVETO:
                if cur: subs.append(cur); closed.append(False)
                cur = [tuple(verts[:2])]
            elif code == Path.LINETO:
                cur.append(tuple(verts[:2]))
            elif code == Path.CLOSEPOLY:
                if cur:
                    subs.append(cur); closed.append(True); cur = []
        if cur: subs.append(cur); closed.append(False)
        if not subs:
            return
        lw = gc.get_linewidth()
        fa = gc.get_alpha() if gc.get_forced_alpha() else None
        face = None
        if rgbFace is not None:
            a = rgbFace[3] if len(rgbFace) > 3 else 1.0
            if fa is not None: a = fa
            face = (tuple(rgbFace[:3]), a)
        ec = gc.get_rgb()
        ea = ec[3] if fa is None else fa
        edge = (tuple(ec[:3]), ea) if lw > 0 and ea > 0 else None
        clip = gc.get_clip_rectangle()
        bb = (clip.x0, clip.y0, clip.x1, clip.y1) if clip is not None else None
        out = []
        for pts, cl in zip(subs, closed):
            if face is not None or cl:
                poly = list(pts)
                if bb: poly = _clip_poly(poly, bb)
                if len(poly) > 2:
                    out.append((poly, True))
            else:
                pl = _clip_line(pts, bb) if bb else [pts]
                for q in pl:
                    out.append((q, False))
        if not out:
            return
        if face is None and edge is None:
            return
        d = gc.get_dashes()
        dash = d[1] if d and d[1] is not None else None
        hatch = gc.get_hatch()
        hc = gc.get_hatch_color() if hatch else None
        self.items.append(dict(kind="path", subs=out, face=face, edge=edge, lw=lw, dash=dash,
                               cap=gc.get_capstyle(), join=gc.get_joinstyle(), hatch=hatch,
                               hcol=tuple(hc[:3]) if hc is not None else None))

    def draw_image(self, gc, x, y, im, transform=None):
        raise RuntimeError("raster image in figure: draw with contourf/fill instead")

    # ------------------------------------------------------------------ text
    def draw_text(self, gc, x, y, s, prop, angle, ismath=False, mtext=None):
        size = prop.get_size_in_points()
        col = gc.get_rgb()[:3]
        if round(angle) % 360 != 0:
            # rotated labels are drawn as glyph outlines (shapes): robust in every renderer
            from matplotlib.textpath import TextPath
            from matplotlib.transforms import Affine2D
            tp = TextPath((0, 0), s, size=size, prop=prop)
            g2 = self.new_gc(); g2.set_linewidth(0)
            self.draw_path(g2, tp, Affine2D().rotate_deg(angle).translate(x, self.H - y), rgbFace=tuple(col) + (1.0,))
            return
        italic = prop.get_style() == "italic"
        bold = prop.get_weight() in ("bold", 700, "heavy")
        runs = []
        if ismath:
            r = _MT.parse(s, 72, prop)
            glyphs = sorted(r.glyphs, key=lambda g: g[4])
            smax = max(g[1] for g in glyphs)
            base = [g[5] for g in glyphs if g[1] == smax][0]
            prev_end = None
            for font, fs, num, gi, ox, oy in glyphs:
                ch = chr(num)
                try:
                    font.set_size(fs, 72)
                    adv = font.load_char(num, flags=2).linearHoriAdvance / 65536.0
                except Exception:
                    adv = 0.5 * fs
                if prev_end is not None and ox - prev_end > 0.14 * smax and ch != " " and runs and not runs[-1][1].endswith(" "):
                    runs[-1][1] += " "
                prev_end = ox + adv
                if ch == "−" or ch.isprintable() or ch == " ":
                    pass
                v = None
                if fs < 0.9 * smax:
                    v = "superscript" if oy > base + 0.05 * smax else "subscript"
                it = "Italic" in font.style_name
                bd = "Bold" in font.style_name
                if font.family_name.lower().startswith("cm"):
                    ch = {0x29: "⇒"}.get(num, ch)
                key = (it, bd, v)
                if runs and runs[-1][0] == key:
                    runs[-1][1] += ch
                else:
                    runs.append([key, ch])
            w = r.width
            runs = [(t, k[0], k[1], k[2]) for k, t in runs]
        else:
            w = self.get_text_width_height_descent(s, prop, False)[0]
            runs = [(s, italic, bold, None)]
        self.items.append(dict(kind="text", x=x, y=self.H - y, w=w, size=size, angle=angle, col=col, runs=runs))

    # ---------------------------------------------------------------- output
    def extent(self):
        xs, ys = [], []
        for it in self.items:
            if it["kind"] == "path":
                pad = it["lw"] / 2 + 0.5
                for pts, _ in it["subs"]:
                    for px, py in pts:
                        xs += [px - pad, px + pad]; ys += [py - pad, py + pad]
            else:
                for cx, cy in self._text_corners(it):
                    xs.append(cx); ys.append(cy)
        return min(xs), min(ys), max(xs), max(ys)

    @staticmethod
    def _text_geom(it):
        size = it["size"]
        asc = 0.905 * size
        bh = 1.16 * size
        bw = it["w"] * 1.12 + 2.0
        th = math.radians(it["angle"])
        c, s_ = math.cos(th), math.sin(th)
        cx, cy = bw / 2.0, asc - bh / 2.0   # local centre (y up)
        gx = it["x"] + cx * c - cy * s_
        gy = it["y"] + cx * s_ + cy * c
        return gx, gy, bw, bh, th

    def _text_corners(self, it):
        gx, gy, bw, bh, th = self._text_geom(it)
        tw = it["w"]
        c, s_ = math.cos(th), math.sin(th)
        asc = 0.905 * it["size"]; desc = 0.2 * it["size"]
        out = []
        for lx, ly in ((0, -desc), (tw, -desc), (tw, asc), (0, asc)):
            out.append((it["x"] + lx * c - ly * s_, it["y"] + lx * s_ + ly * c))
        return out

    def to_drawingml(self, name, descr, pad=5.0, crop=True):
        if crop:
            x0, y0, x1, y1 = self.extent()
        else:
            x0, y0, x1, y1 = 0, 0, self.W, self.H
        x0 -= pad; y0 -= pad; x1 += pad; y1 += pad
        wpt, hpt = x1 - x0, y1 - y0
        cx_, cy_ = int(round(wpt * EMU)), int(round(hpt * EMU))
        body = []
        sid = [1]

        def pt(px, py):  # display (y up) -> group-local EMU
            return (px - x0) * EMU, (y1 - py) * EMU

        for it in self.items:
            sid[0] += 1
            if it["kind"] == "path":
                body.append(self._path_xml(it, pt, sid[0]))
            else:
                body.append(self._text_xml(it, pt, x0, y1, sid[0]))
        xml = (
            '<w:drawing xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
            'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
            'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
            'xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" '
            'xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape">'
            f'<wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx_}" cy="{cy_}"/>'
            '<wp:effectExtent l="0" t="0" r="0" b="0"/>'
            f'<wp:docPr id="{abs(hash(name)) % 9000 + 100}" name="{escape(name)}" descr="{escape(descr)}"/>'
            '<wp:cNvGraphicFramePr/>'
            '<a:graphic><a:graphicData uri="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup">'
            '<wpg:wgp><wpg:cNvGrpSpPr/><wpg:grpSpPr><a:xfrm><a:off x="0" y="0"/>'
            f'<a:ext cx="{cx_}" cy="{cy_}"/><a:chOff x="0" y="0"/><a:chExt cx="{cx_}" cy="{cy_}"/></a:xfrm></wpg:grpSpPr>'
            + "".join(body) +
            '</wpg:wgp></a:graphicData></a:graphic></wp:inline></w:drawing>')
        return xml, wpt, hpt

    # ----------------------------------------------------------------- xml parts
    @staticmethod
    def _fill(col_alpha):
        (rgb, a) = col_alpha
        al = '' if a >= 0.999 else f'<a:alpha val="{int(a*100000)}"/>'
        return f'<a:solidFill><a:srgbClr val="{_hex(rgb)}">{al}</a:srgbClr></a:solidFill>'

    def _path_xml(self, it, pt, sid):
        allp = [pt(px, py) for pts, _ in it["subs"] for px, py in pts]
        xs = [p[0] for p in allp]; ys = [p[1] for p in allp]
        ox, oy = min(xs), min(ys)
        w = max(max(xs) - ox, 1.0); h = max(max(ys) - oy, 1.0)
        paths = []
        for pts, cl in it["subs"]:
            seg = []
            for k, (px, py) in enumerate(pts):
                X, Y = pt(px, py)
                tag = "moveTo" if k == 0 else "lnTo"
                seg.append(f'<a:{tag}><a:pt x="{int(round(X-ox))}" y="{int(round(Y-oy))}"/></a:{tag}>')
            if cl:
                seg.append("<a:close/>")
            paths.append("".join(seg))
        fillattr = "" if it["face"] is not None else ' fill="none"'
        pl = f'<a:path w="{int(round(w))}" h="{int(round(h))}"{fillattr}>{"".join(paths)}</a:path>'
        geom = ('<a:custGeom><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l="0" t="0" r="r" b="b"/>'
                f'<a:pathLst>{pl}</a:pathLst></a:custGeom>')
        if it["face"] is None:
            fill = "<a:noFill/>"
        elif it["hatch"]:
            ch = [HATCH.get(c) for c in it["hatch"] if c in HATCH]
            prst = ch[0] if ch else "wdUpDiag"
            fg = it["hcol"] or (0, 0, 0)
            fill = (f'<a:pattFill prst="{prst}"><a:fgClr><a:srgbClr val="{_hex(fg)}"/></a:fgClr>'
                    f'<a:bgClr><a:srgbClr val="{_hex(it["face"][0])}"/></a:bgClr></a:pattFill>')
        else:
            fill = self._fill(it["face"])
        if it["edge"] is None:
            ln = "<a:ln><a:noFill/></a:ln>"
        else:
            cap = {"butt": "flat", "round": "rnd", "projecting": "sq"}.get(it["cap"], "flat")
            join = {"miter": "<a:miter lim=\"800000\"/>", "round": "<a:round/>", "bevel": "<a:bevel/>"}.get(it["join"], "<a:round/>")
            dash = ""
            if it["dash"]:
                lw = max(it["lw"], 0.1)
                ds = "".join(f'<a:ds d="{int(v/lw*100000)}" sp="{int(g/lw*100000)}"/>'
                             for v, g in zip(it["dash"][0::2], it["dash"][1::2]))
                dash = f"<a:custDash>{ds}</a:custDash>"
            ln = f'<a:ln w="{int(it["lw"]*EMU)}" cap="{cap}">{self._fill(it["edge"])}{dash}{join}</a:ln>'
        return (f'<wps:wsp><wps:cNvPr id="{sid}" name="shape {sid}"/><wps:cNvSpPr/><wps:spPr>'
                f'<a:xfrm><a:off x="{int(round(ox))}" y="{int(round(oy))}"/><a:ext cx="{int(round(w))}" cy="{int(round(h))}"/></a:xfrm>'
                f'{geom}{fill}{ln}</wps:spPr><wps:bodyPr/></wps:wsp>')

    def _text_xml(self, it, pt, x0, y1, sid):
        size = it["size"]
        asc = 0.905 * size
        bh = 1.16 * size
        bw = it["w"] * 1.12 + 2.0
        ang = round(it["angle"]) % 360
        vert = None
        if False:
            pass
        else:
            gx, gy, bw, bh, th = self._text_geom(it)
            cxE, cyE = pt(gx, gy)
            wE, hE = bw * EMU, bh * EMU
            offx, offy = cxE - wE / 2, cyE - hE / 2
            rot = int(round((-math.degrees(th)) % 360 * 60000))
        rr = []
        for text, italic, bold, va in it["runs"]:
            rp = (f'<w:rFonts w:ascii="{FONT}" w:hAnsi="{FONT}" w:cs="{FONT}"/>'
                  + ("<w:b/>" if bold else "") + ("<w:i/>" if italic else "")
                  + f'<w:color w:val="{_hex(it["col"])}"/>'
                  + (f'<w:position w:val="{int(round(size*2*(0.36 if va == "superscript" else -0.14)))}"/>' if va else "")
                  + f'<w:sz w:val="{int(round(size*2*(1.0 if va is None else 0.7)))}"/>')
            rr.append(f'<w:r><w:rPr>{rp}</w:rPr><w:t xml:space="preserve">{escape(text)}</w:t></w:r>')
        return (f'<wps:wsp><wps:cNvPr id="{sid}" name="text {sid}"/><wps:cNvSpPr txBox="1"/><wps:spPr>'
                f'<a:xfrm rot="{rot}"><a:off x="{int(round(offx))}" y="{int(round(offy))}"/>'
                f'<a:ext cx="{int(round(wE))}" cy="{int(round(hE))}"/></a:xfrm>'
                '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></wps:spPr>'
                '<wps:txbx><w:txbxContent><w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/>'
                '<w:jc w:val="left"/></w:pPr>' + "".join(rr) + '</w:p></w:txbxContent></wps:txbx>'
                f'<wps:bodyPr wrap="none" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t" rtlCol="0"><a:noAutofit/></wps:bodyPr></wps:wsp>')


def figure_to_drawingml(fig, name, descr):
    """Draw a (dpi=72) figure with the shape renderer and return (xml, width_pt, height_pt)."""
    w, h = fig.get_size_inches() * 72
    ren = ShapeRenderer(w, h)
    fig.draw(ren)
    xml, wpt, hpt = ren.to_drawingml(name, descr)
    return xml, wpt, hpt, ren
