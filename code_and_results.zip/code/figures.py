"""Generate all manuscript figures at publication resolution from cached results."""
import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, FancyArrowPatch, Rectangle, FancyBboxPatch
from matplotlib.lines import Line2D
import matplotlib.colors as mcolors
import matplotlib.ticker
import model as m
import shapes as shp

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
FIG = os.path.join(HERE, "figures")
os.makedirs(FIG, exist_ok=True)
DPI = 600

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Liberation Sans", "Arial", "DejaVu Sans"],
    "font.size": 8.0,
    "axes.labelsize": 8.5,
    "axes.titlesize": 8.5,
    "xtick.labelsize": 7.5,
    "ytick.labelsize": 7.5,
    "legend.fontsize": 7.2,
    "axes.linewidth": 0.7,
    "xtick.major.width": 0.7,
    "ytick.major.width": 0.7,
    "xtick.major.size": 3.0,
    "ytick.major.size": 3.0,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "legend.frameon": False,
    "lines.linewidth": 1.3,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.02,
    "mathtext.fontset": "custom",
    "mathtext.rm": "Liberation Sans",
    "mathtext.it": "Liberation Sans:italic",
    "mathtext.bf": "Liberation Sans:bold",
})

# colour-vision-safe palette
C = dict(rock="#4a4a4a", sap="#c9a227", reg="#e0c878", water="#2c7fb8",
         hot="#b2182b", cool="#2166ac", mid="#7a7a7a", green="#1b7837",
         purple="#762a83", orange="#d95f02")
SEQ = ["#2166ac", "#67a9cf", "#7a7a7a", "#ef8a62", "#b2182b"]

COL1, COL2 = 3.46, 6.10        # text-block width of the manuscript page (16 cm)


def panel(ax, letter, x=-0.155, y=1.045):
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=9.2,
            fontweight="bold", va="bottom", ha="left")


def _text_boxes(fig):
    fig.canvas.draw()
    rend = fig.canvas.get_renderer()
    ticklabs = set()
    valid = []
    for ax in fig.axes:
        for axis in (ax.xaxis, ax.yaxis):
            if not axis.get_visible() or not ax.get_visible():
                continue
            for which in ("major", "minor"):
                ticks = axis.get_major_ticks() if which == "major" else axis.get_minor_ticks()
                locs = axis.get_majorticklocs() if which == "major" else axis.get_minorticklocs()
                lo, hi = sorted(axis.get_view_interval())
                labs = axis.get_majorticklabels() if which == "major" else axis.get_minorticklabels()
                for t, loc in zip(labs, locs):
                    ticklabs.add(id(t))
                    if lo - 1e-12 <= loc <= hi + 1e-12:
                        valid.append(t)
    out = []
    cands = [t for t in fig.findobj(matplotlib.text.Text) if id(t) not in ticklabs] + valid
    for t in cands:
        if not t.get_visible() or not t.get_text().strip():
            continue
        try:
            bb = t.get_window_extent(rend)
        except Exception:
            continue
        if bb.width < 1 or bb.height < 1:
            continue
        out.append((t.get_text().replace("\n", " ")[:28], bb))
    return out


def check_overlaps(fig, name):
    """Report any pair of visible text labels whose boxes intersect."""
    boxes = _text_boxes(fig)
    bad = []
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i][1], boxes[j][1]
            if a.x0 < b.x1 - 0.5 and b.x0 < a.x1 - 0.5 and a.y0 < b.y1 - 0.5 and b.y0 < a.y1 - 0.5:
                bad.append((boxes[i][0], boxes[j][0]))
    for a, b in bad:
        print(f"  OVERLAP in {name}: '{a}' x '{b}'")
    if not bad:
        print(f"  no text overlaps in {name}")
    return bad


ALT = {}


def save(fig, name):
    check_overlaps(fig, name)
    p = os.path.join(FIG, name)
    fig.savefig(p + ".png", dpi=DPI)
    fig.savefig(p + ".pdf")
    fig.savefig(p + ".tiff", dpi=DPI, pil_kwargs={"compression": "tiff_lzw"})
    fig.set_dpi(72)
    xml, wpt, hpt, ren = shp.figure_to_drawingml(fig, name, ALT.get(name, name))
    os.makedirs(os.path.join(FIG, "shapes"), exist_ok=True)
    open(os.path.join(FIG, "shapes", name + ".xml"), "w").write(xml)
    json.dump(dict(w_pt=wpt, h_pt=hpt, n=len(ren.items)), open(os.path.join(FIG, "shapes", name + ".json"), "w"))
    print(f"  shapes: {len(ren.items)}  size {wpt/72:.2f} x {hpt/72:.2f} in")
    plt.close(fig)
    print("wrote", name, flush=True)


# =============================================================================
# Figure 1  Model definition
# =============================================================================
def fig1():
    from matplotlib.patches import Patch
    fig = plt.figure(figsize=(9.2, 4.4))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.55, 1.0], wspace=0.10)
    ax = fig.add_subplot(gs[0, 0])

    x = np.linspace(0, 10, 600)
    eta = 3.05 + 0.60 * np.cos(0.62 * x) + 0.16 * np.cos(1.9 * x + 1.0)
    Hs = 1.35 + 1.05 * np.cos(0.62 * x + 0.32) + 0.14 * np.cos(2.2 * x)
    Hs = np.clip(Hs, 0.06, None)
    zw = eta - Hs
    zr = eta - 0.30 * Hs

    ax.fill_between(x, -0.6, zw, color="#8d8d8d", alpha=0.95, lw=0)
    ax.fill_between(x, zw, zr, color=C["sap"], alpha=0.60, lw=0)
    ax.fill_between(x, zr, eta, color=C["reg"], alpha=0.85, lw=0)
    ax.plot(x, eta, color="k", lw=1.5)
    ax.plot(x, zw, color=C["hot"], lw=1.6)
    ax.plot(x, zr, color="#6b6b6b", lw=0.9, ls=(0, (4, 2)))

    rng = np.random.default_rng(3)
    for xf in np.linspace(0.25, 9.75, 46):
        dens = np.interp(xf, x, Hs)
        if rng.random() > 0.30 + 0.42 * dens / Hs.max():
            continue
        top = np.interp(xf, x, zw)
        dep = 0.35 + 1.1 * rng.random() * (0.35 + dens / Hs.max())
        tilt = (rng.random() - 0.5) * 0.55
        ax.plot([xf, xf + tilt], [top, max(top - dep, -0.55)], color="#3d3d3d",
                lw=0.55, alpha=0.72, solid_capstyle="butt")

    def arrow(x0, y0, x1, y1, col, lw=1.2, style="-|>", ms=7):
        ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle=style,
                                     mutation_scale=ms, color=col, lw=lw,
                                     shrinkA=0, shrinkB=0, zorder=6))

    for xf in [1.9, 3.5, 6.3, 8.0]:
        arrow(xf, np.interp(xf, x, eta) + 0.05, xf, np.interp(xf, x, zw) + 0.06, C["water"], 1.0, ms=6)
    for xf in [2.7, 5.0, 7.0]:
        yb = np.interp(xf, x, zw)
        arrow(xf, yb - 0.06, xf, yb - 0.62, C["hot"], 1.25, ms=7)

    arrow(1.2, np.interp(1.2, x, eta) + 0.30, 2.6, np.interp(2.6, x, eta) + 0.26, C["green"], 1.3, ms=8)
    arrow(8.2, np.interp(8.2, x, eta) + 0.30, 6.8, np.interp(6.8, x, eta) + 0.26, C["green"], 1.3, ms=8)
    ax.text(5.0, 5.12, "$q_s = -D\\ $grad$\\ \\eta\\ f(|$grad$\\ \\eta|)\\ g(H)$",
            color=C["green"], fontsize=7.4, ha="center")

    for xf in [0.55, 9.45]:
        arrow(xf, -0.50, xf, 0.12, C["purple"], 1.25, ms=7)
        ax.text(xf, -0.86, "$U$", color=C["purple"], fontsize=8, ha="center")

    xb = 0.95
    yt, yb_ = np.interp(xb, x, eta), np.interp(xb, x, zw)
    ax.annotate("", xy=(xb, yt), xytext=(xb, yb_),
                arrowprops=dict(arrowstyle="<->", color="k", lw=0.85))
    ax.text(xb - 0.12, 0.5 * (yt + yb_), "$H$", fontsize=8.5, ha="right", va="center")

    ax.text(9.9, np.interp(9.9, x, eta) + 0.18, r"$\eta(x,y,t)$", fontsize=8, ha="right", va="bottom")
    ax.text(9.9, 0.45, r"$z_w(x,y,t)$", fontsize=8, ha="right", va="center", color=C["hot"],
            bbox=dict(fc="white", ec="none", alpha=0.9, pad=1.5))

    ax.annotate("", xy=(9.62, np.interp(9.62, x, zw) - 0.03), xytext=(9.62, 0.72),
                arrowprops=dict(arrowstyle="-", color=C["hot"], lw=0.7), zorder=5)
    ax.set_xlim(0, 10); ax.set_ylim(-1.15, 5.55)
    ax.set_xticks([]); ax.set_yticks([])
    for sp in ax.spines.values():
        sp.set_visible(False)
    handles = [Patch(fc=C["reg"], ec="none", alpha=0.85, label="mobile regolith"),
               Patch(fc=C["sap"], ec="none", alpha=0.6, label="saprolite"),
               Patch(fc="#8d8d8d", ec="none", label="fresh crystalline basement (structural index $S$)"),
               Line2D([0], [0], color=C["water"], lw=1.1, marker=">", ms=3.5, label="infiltration $q_w$"),
               Line2D([0], [0], color=C["hot"], lw=1.3, marker=">", ms=3.5, label="front propagation $W$"),
               Line2D([0], [0], color=C["green"], lw=1.3, marker=">", ms=3.5, label="sediment transport $q_s$")]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.01), ncol=2,
              fontsize=6.8, handlelength=1.8, columnspacing=1.4, labelspacing=0.5)
    panel(ax, "a", x=-0.02, y=0.955)

    # ---- panel b: resistances in series ----
    axb = fig.add_subplot(gs[0, 1])
    axb.set_xlim(-0.5, 10.5); axb.set_ylim(0, 10)
    axb.axis("off")
    bw = 4.5
    axb.add_patch(FancyBboxPatch((0.0, 5.9), bw, 3.2, boxstyle="round,pad=0.10", fc="#e8eef5", ec=C["cool"], lw=1.1))
    axb.text(bw / 2, 8.45, "reaction control", ha="center", va="center", fontsize=8.6, color=C["cool"])
    axb.text(bw / 2, 7.0, "$W_R = W_0 S^{\\alpha}$", ha="center", va="center", fontsize=9.2, color=C["cool"])
    axb.add_patch(FancyBboxPatch((5.5, 5.9), bw, 3.2, boxstyle="round,pad=0.10", fc="#fbeae7", ec=C["hot"], lw=1.1))
    axb.text(5.5 + bw / 2, 8.45, "transport control", ha="center", va="center", fontsize=8.6, color=C["hot"])
    axb.text(5.5 + bw / 2, 7.0, "$W_T = W_0 S^{\\beta}$ /\n$[Da_0 (1 + H/H_*)]$", ha="center", va="center", fontsize=8.0, linespacing=1.3, color=C["hot"])
    axb.add_patch(FancyArrowPatch((bw + 0.12, 7.5), (5.38, 7.5), arrowstyle="-", lw=1.4, color="k"))
    for xc in (bw / 2, 5.5 + bw / 2):
        axb.add_patch(FancyArrowPatch((xc, 5.7), (xc, 5.15), arrowstyle="-|>", mutation_scale=8, lw=1.2, color="k"))
    axb.add_patch(FancyBboxPatch((0.0, 3.35), 10.0, 1.65, boxstyle="round,pad=0.10", fc="#f2f2f2", ec="#4a4a4a", lw=1.1))
    axb.text(5.0, 4.18, "$W^{-1} = W_R^{-1} + W_T^{-1}$  \u2192  $W = W_0 S^{\\alpha} / (1 + Da)$",
             ha="center", va="center", fontsize=8.0)
    axb.add_patch(FancyArrowPatch((5.0, 3.15), (5.0, 2.35), arrowstyle="-|>", mutation_scale=8, lw=1.2, color="k"))
    axb.text(5.0, 1.85, "$Da = Da_0\\,S^{\\alpha-\\beta}\\,(1 + H/H_*)$", ha="center", va="center", fontsize=8.8)
    axb.text(5.0, 0.55, "$Da < 1$: reaction limited\n$Da > 1$: transport limited", ha="center", va="center",
             fontsize=8.2, color="#4a4a4a", linespacing=1.3)
    panel(axb, "b", x=-0.03, y=0.955)

    save(fig, "fig01_model_definition")


# =============================================================================
# Figure 2  Structure of the weathering law
# =============================================================================
def fig2():
    d = np.load(f"{RES}/analytical.npz")
    p = m.Params(W0=30e-6, Da0=1.0, Hstar=4.0, alpha=1.5, beta=1.0,
                 eps=0.10, D=0.05, Sc=0.80, Ht=0.50, U=3e-6)
    fig, axs = plt.subplots(2, 2, figsize=(COL2, 6.5))
    fig.subplots_adjust(hspace=0.36, wspace=0.42, left=0.10, right=0.94, top=0.97, bottom=0.07)

    # (a) W(H) curves with asymptotes
    ax = axs[0, 0]
    H, Sv, Wc = d["H"], d["Svals"], d["Wcurves"]
    for i, S in enumerate(Sv):
        ax.plot(H, Wc[i] * 1e6, color=SEQ[i], label=f"$S$ = {S:g}")
    ax.axhline(p.U * 1e6, color="k", ls=(0, (5, 2)), lw=1.0)
    ax.text(112, p.U * 1e6 * 1.16, "$U$", fontsize=8, ha="right")
    Sd = 2.5
    ax.plot(H, np.full_like(H, p.W0 * Sd ** p.alpha * 1e6), color=SEQ[4],
            lw=0.8, ls=":", alpha=0.9)
    ax.text(3, p.W0 * Sd ** p.alpha * 1e6 * 0.72, "$W_R$ (reaction limit, $S$ = 2.5)",
            fontsize=6.8, color=SEQ[4], va="top")
    Wt = p.W0 * Sd ** p.beta / (p.Da0 * (1 + H / p.Hstar)) * 1e6
    ax.plot(H, Wt, color=SEQ[4], lw=0.8, ls="-.", alpha=0.9)
    ax.text(70, 14, "$W_T$ (transport limit,\n$S$ = 2.5)", fontsize=6.8, color=SEQ[4])
    ax.set_yscale("log")
    ax.set_xlabel("mantle thickness $H$ (m)")
    ax.set_ylabel("front propagation $W$ (m Myr$^{-1}$)")
    ax.set_xlim(0, 120); ax.set_ylim(0.7, 700)
    ax.legend(loc="upper right", ncol=3, columnspacing=0.8, handlelength=1.3, fontsize=6.6)
    panel(ax, "a")

    # (b) Damkohler field
    ax = axs[0, 1]
    Hg = np.linspace(0, 120, 160)
    Sg2 = np.linspace(0.15, 3.0, 160)
    HH, SS = np.meshgrid(Hg, Sg2)
    Da = m.damkohler(HH, SS, p)
    lv = np.array([0.25, 0.5, 1, 2, 4, 8, 16, 32])
    cf = ax.contourf(HH, SS, Da, levels=np.logspace(-1, 2, 25),
                     norm=mcolors.LogNorm(), cmap="RdBu_r", extend="both")
    cs = ax.contour(HH, SS, Da, levels=lv, colors="k", linewidths=0.45,
                    alpha=0.55)
    ax.clabel(cs, fmt="%g", fontsize=6.0, inline=True)
    ax.contour(HH, SS, Da, levels=[1.0], colors="k", linewidths=1.6)
    cb = fig.colorbar(cf, ax=ax, pad=0.025, aspect=22,
                      ticks=[0.1, 1, 10, 100])
    cb.set_label("Damköhler number $Da$", fontsize=7.6)
    cb.ax.set_yticklabels(["0.1", "1", "10", "100"])
    cb.ax.tick_params(labelsize=7)
    ax.text(5, 2.62, "transport limited", fontsize=7.0, color="#5c1010")
    ax.text(4, 0.34, "reaction\nlimited", fontsize=7.0, color="#10305c")
    ax.set_xlabel("mantle thickness $H$ (m)")
    ax.set_ylabel("structural index $S$")
    panel(ax, "b")

    # (c) equilibrium thickness and threshold
    ax = axs[1, 0]
    Sg, Heq, Sc = d["Sg"], d["Heq"], float(d["Sc"])
    ax.fill_between(Sg, 0, 120, where=Sg < Sc, color="#e6d5d2", lw=0)
    ax.plot(Sg, Heq, color=C["cool"], lw=1.7)
    ax.axvline(Sc, color=C["hot"], lw=1.2, ls=(0, (4, 2)))
    ax.text(Sc + 0.05, 112, f"$S_c$ = {Sc:.3f}", color=C["hot"], fontsize=7.6,
            rotation=90, va="top", ha="left")
    ax.text(0.62, 78, "stripped (left of $S_c$):\nno mantled steady state", fontsize=7.0,
            color="#7a2020", va="center", ha="left")
    ax.text(1.55, 22, "mantled", fontsize=7.4, color=C["cool"])
    ax.set_xlabel("structural index $S$")
    ax.set_ylabel("equilibrium thickness $H_{eq}$ (m)")
    ax.set_xlim(0.12, 3.0); ax.set_ylim(0, 120)
    panel(ax, "c")

    # (d) regime diagram
    ax = axs[1, 1]
    ratio, Sgrid, Z = d["ratio"], d["Sgrid"], d["Z"]
    cf = ax.contourf(Sgrid, ratio, np.where(Z > 0, Z, np.nan),
                     levels=np.linspace(0, 150, 31), cmap="YlGnBu", extend="max")
    ax.contourf(Sgrid, ratio, np.where(Z <= 0, 1, np.nan), levels=[0, 2],
                colors=["#e6d5d2"])
    ax.plot(d["Sc_line"], ratio, color=C["hot"], lw=1.6)
    cb = fig.colorbar(cf, ax=ax, pad=0.025, aspect=22)
    cb.set_label("$H_{eq}$ (m)", fontsize=7.6)
    cb.ax.tick_params(labelsize=7)
    ax.scatter([1.0], [p.U / p.W0], s=26, marker="o", facecolor="w",
               edgecolor="k", lw=1.0, zorder=5)
    ax.text(1.12, p.U / p.W0 * 1.06, "reference\nconfiguration", fontsize=6.8)
    ax.text(0.17, 0.55, "stripped", fontsize=7.4, color="#7a2020", rotation=0)
    ax.set_yscale("log")
    ax.set_xlabel("structural index $S$")
    ax.set_ylabel("$U / W_0$")
    ax.set_xlim(0.15, 3.0)
    panel(ax, "d")

    save(fig, "fig02_weathering_law")


# =============================================================================
# Figure 3  Verification
# =============================================================================
def fig3():
    d = np.load(f"{RES}/verification.npz")
    fig, axs = plt.subplots(1, 3, figsize=(COL2, 2.45))
    fig.subplots_adjust(wspace=0.40)

    ax = axs[0]
    dt, e = d["dts"], d["errs"]
    k = e > 0
    sl = np.polyfit(np.log(dt[k]), np.log(e[k]), 1)[0]
    ax.loglog(dt[k], e[k], "o", ms=4.2, color=C["cool"], mfc="w", mew=1.2)
    ref = e[k][-1] * (dt[k] / dt[k][-1]) ** 1.0
    ax.loglog(dt[k], ref, "-", color="#9a9a9a", lw=1.0)
    ax.text(0.05, 0.90, f"observed order {sl:.2f}\nreference slope 1",
            transform=ax.transAxes, fontsize=7.0, va="top")
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_xlabel("time step $\\Delta t$ (yr)")
    ax.set_ylabel("error in $H$ (m)")
    panel(ax, "a", x=-0.34)

    ax = axs[1]
    dx, se = d["sp_dx"], d["sp_err"]
    sl2 = np.polyfit(np.log(dx), np.log(se), 1)[0]
    ax.loglog(dx, se, "s", ms=4.2, color=C["hot"], mfc="w", mew=1.2)
    ax.loglog(dx, se[-1] * (dx / dx[-1]) ** 2.0, "-", color="#9a9a9a", lw=1.0)
    ax.text(0.05, 0.90, f"observed order {sl2:.2f}\nreference slope 2",
            transform=ax.transAxes, fontsize=7.0, va="top")
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_xlabel("grid spacing $\\Delta x$ (m)")
    ax.set_ylabel("RMS error in div $q_s$ (m yr$^{-1}$)")
    panel(ax, "b", x=-0.38)

    ax = axs[2]
    na, an = d["num_H"], d["ana_H"]
    lim = [0, 105]
    ax.plot(lim, lim, "-", color="#9a9a9a", lw=1.0)
    ax.plot(an, na, "o", ms=4.4, color=C["green"], mfc="w", mew=1.2)
    err = np.max(np.abs(na - an) / np.maximum(an, 1e-9)) * 100
    ax.text(0.05, 0.90, f"max deviation\n{err:.2f} %", transform=ax.transAxes,
            fontsize=7.0, va="top")
    ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel("analytical $H_{eq}$ (m)")
    ax.set_ylabel("simulated $H$ (m)")
    ax.set_aspect("equal")
    panel(ax, "c", x=-0.34)

    save(fig, "fig03_verification")


# =============================================================================
# Figure 4  Transient behaviour
# =============================================================================
def fig4():
    d = np.load(f"{RES}/transient.npz")
    md = np.load(f"{RES}/main2d.npz")
    p = m.Params(W0=30e-6, Da0=1.0, Hstar=4.0, alpha=1.5, beta=1.0,
                 eps=0.10, D=0.05, Sc=0.80, Ht=0.50, U=3e-6)
    fig, axs = plt.subplots(1, 3, figsize=(COL2, 2.55))
    fig.subplots_adjust(wspace=0.62, left=0.095, right=0.925, bottom=0.2, top=0.93)

    names = [("mantled", C["cool"]), ("marginal", C["orange"]),
             ("stripped", C["hot"])]
    LS = {"mantled": "-", "marginal": (0, (5, 1.5)), "stripped": (0, (1, 1.2))}
    ax = axs[0]
    for nm, col in names:
        t, H = d[f"t_{nm}"] / 1e6, d[f"H_{nm}"]
        S = float(d[f"S_{nm}"])
        ax.plot(t, H, color=col, ls=LS[nm], label=f"$S$ = {S:.2f}")
        he = m.H_eq(S, p)
        if he > 0:
            ax.axhline(he, color=col, lw=0.75, ls=":")
    ax.set_xlabel("time (Myr)")
    ax.set_ylabel("mantle thickness $H$ (m)")
    ax.set_xlim(0, 120)
    hl, lb = ax.get_legend_handles_labels()
    hl.append(Line2D([0], [0], color="#5a5a5a", lw=0.9, ls=":"))
    lb.append("analytical $H_{eq}$")
    ax.legend(hl, lb, loc="center right", handlelength=1.8, bbox_to_anchor=(1.0, 0.55))
    panel(ax, "a", x=-0.32)

    ax = axs[1]
    for nm, col in names:
        t, W = d[f"t_{nm}"] / 1e6, d[f"W_{nm}"] * 1e6
        ax.plot(t, W, color=col, ls=LS[nm])
    ax.axhline(p.U * 1e6, color="k", ls=(0, (5, 2)), lw=1.0)
    ax.text(118, p.U * 1e6 * 1.12, "$W = U$", fontsize=7.2, ha="right")
    ax.set_xlabel("time (Myr)")
    ax.set_ylabel("front propagation $W$ (m Myr$^{-1}$)")
    ax.set_xlim(0, 120); ax.set_yscale("log")
    ax.set_yticks([2, 3, 5, 10, 20]); ax.set_yticklabels(["2", "3", "5", "10", "20"])
    ax.minorticks_off()
    panel(ax, "b", x=-0.34)

    ax = axs[2]
    h = md["hist"]
    t = h[:, 0] / 1e6
    ax.plot(t, h[:, 1], color=C["cool"], label="mean $H$")
    ax.set_xlabel("time (Myr)")
    ax.set_ylabel("mean $H$ (m)", color=C["cool"])
    ax.tick_params(axis="y", colors=C["cool"])
    ax.set_xlim(0, 120); ax.set_ylim(0, 55)
    ax2 = ax.twinx()
    ax2.plot(t, h[:, 2], color=C["hot"], ls=(0, (5, 2)), label="relief")
    ax2.set_ylabel("relief (m)", color=C["hot"])
    ax2.tick_params(axis="y", colors=C["hot"])
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(True)
    ax2.spines["right"].set_color(C["hot"])
    ax.spines["left"].set_color(C["cool"])
    ax.text(0.04, 0.96, "2D simulation", transform=ax.transAxes,
            fontsize=6.9, va="top", color="#4a4a4a")
    panel(ax, "c", x=-0.34)

    save(fig, "fig04_transient")


# =============================================================================
# Figure 5  Two-dimensional simulation
# =============================================================================
def fig5():
    d = np.load(f"{RES}/main2d.npz")
    i = slice(3, -3)
    S, H, eta, Heq = d["S"][i, i], d["H"][i, i], d["eta"][i, i], d["Heq"][i, i]
    dx, Sc = float(d["dx"]), float(d["Sc"])
    n = S.shape[0]
    xs = (np.arange(n) + 0.5) * dx / 1000
    ext = [0, n * dx / 1000, 0, n * dx / 1000]
    rng = np.random.default_rng(11)

    fig, axs = plt.subplots(2, 2, figsize=(COL2, 6.6))
    fig.subplots_adjust(hspace=0.30, wspace=0.55, left=0.09, right=0.93, top=0.95, bottom=0.07)

    def mapax(ax, Z, levels, cmap, label, extend="neither", extra=None):
        cf = ax.contourf(xs, xs, Z, levels=levels, cmap=cmap, extend=extend)
        if extra:
            extra(ax)
        ax.set_xlim(ext[0], ext[1]); ax.set_ylim(ext[2], ext[3]); ax.set_aspect("equal")
        cb = fig.colorbar(cf, ax=ax, pad=0.025, aspect=24, fraction=0.046)
        cb.set_label(label, fontsize=7.6)
        cb.ax.tick_params(labelsize=7)
        ax.set_xlabel("x (km)"); ax.set_ylabel("y (km)")
        return cf, cb

    ax = axs[0, 0]
    mapax(ax, S, np.linspace(0.15, 2.55, 13), "viridis", "structural index $S$", "max",
          lambda a: a.contour(xs, xs, S, levels=[Sc], colors="w", linewidths=1.3))
    ax.text(0.5, 1.02, f"white contour: $S_c$ = {Sc:.3f}", transform=ax.transAxes,
            fontsize=6.9, va="bottom", ha="center")
    panel(ax, "a", x=-0.15)

    ax = axs[0, 1]
    mapax(ax, H, np.arange(0, 121, 10), "YlGnBu", "mantle thickness $H$ (m)", "max",
          lambda a: a.contour(xs, xs, S, levels=[Sc], colors="#b2182b", linewidths=1.1))
    ax.text(0.5, 1.02, "red contour: $S_c$", transform=ax.transAxes, fontsize=6.9,
            va="bottom", ha="center", color="#b2182b")
    panel(ax, "b", x=-0.15)

    ax = axs[1, 0]
    lv = [0, 20, 40, 50, 60, 70, 80, 90, 100, 120, 150, 180, 210, 240]
    mapax(ax, eta, lv, "cividis", "elevation $\\eta$ (m)", "neither",
          lambda a: a.contour(xs, xs, S, levels=[Sc], colors="#b2182b", linewidths=1.1))
    ax.text(0.5, 1.02, "red contour: $S_c$; uneven class intervals", transform=ax.transAxes, fontsize=6.9,
            va="bottom", ha="center")
    panel(ax, "c", x=-0.15)

    ax = axs[1, 1]
    Hq, Hs_ = Heq.ravel(), H.ravel()
    below = S.ravel() < Sc
    bins = np.arange(0, Hq.max() + 6, 6.0)
    mid, lo, hi, med = [], [], [], []
    for k in range(len(bins) - 1):
        mk = (Hq >= bins[k]) & (Hq < bins[k + 1]) & ~below
        if mk.sum() >= 15:
            mid.append(0.5 * (bins[k] + bins[k + 1]))
            q = np.percentile(Hs_[mk], [5, 50, 95]); lo.append(q[0]); med.append(q[1]); hi.append(q[2])
    ax.fill_between(mid, lo, hi, color="#cfd8e3", lw=0, label="5\u201395 % range")
    ax.plot(mid, med, color=C["cool"], lw=1.3, label="median")
    ia = np.where(~below)[0]; ia = rng.choice(ia, 350, replace=False)
    ax.scatter(Hq[ia], Hs_[ia], s=3.0, alpha=0.5, color=C["cool"], lw=0)
    ax.scatter(Hq[below], Hs_[below], s=5.0, alpha=0.85, color=C["hot"], lw=0, label="$S < S_c$ (all)")
    lim = [0, max(Hs_.max(), Hq.max()) * 1.05]
    ax.plot(lim, lim, color="#555555", lw=1.0, ls=(0, (4, 2)))
    r = np.corrcoef(Hs_, Hq)[0, 1]
    ax.text(0.05, 0.94, f"$r$ = {r:.3f}", transform=ax.transAxes, fontsize=8, va="top")
    ax.set_xlabel("analytical $H_{eq}(S)$ (m)")
    ax.set_ylabel("simulated $H$ (m)")
    ax.set_xlim(lim); ax.set_ylim(lim); ax.set_aspect("equal")
    ax.legend(loc="lower right", handlelength=1.1, fontsize=6.4, markerscale=1.8)
    panel(ax, "d", x=-0.17)

    save(fig, "fig05_simulation")


# =============================================================================
# Figure 6  Structural control test
# =============================================================================
def fig6():
    d = np.load(f"{RES}/structuretest.npz")
    Sc = float(d["Sc"]); seeds = d["seeds"]
    fig, axs = plt.subplots(1, 3, figsize=(COL2, 2.55))
    fig.subplots_adjust(wspace=0.62, left=0.095, right=0.985, bottom=0.2, top=0.93)

    allS, allE, allH, dEta, rr = [], [], [], [], []
    for s in seeds:
        S, H, e = d[f"S_{s}"], d[f"H_{s}"], d[f"eta_{s}"]
        e = e - np.median(e)
        allS.append(S.ravel()); allE.append(e.ravel()); allH.append(H.ravel())
        mk = S < Sc
        dEta.append(e[mk].mean() - e[~mk].mean())
        rr.append(np.corrcoef(e.ravel(), S.ravel())[0, 1])
    allS = np.concatenate(allS); allE = np.concatenate(allE)
    allH = np.concatenate(allH)

    ax = axs[0]
    bl, ab = allS < Sc, allS >= Sc
    bins = np.linspace(-40, 110, 41)
    ax.hist(allE[ab], bins=bins, color=C["cool"], alpha=0.60, lw=0.5,
            edgecolor=C["cool"], density=True, label="$S > S_c$")
    ax.hist(allE[bl], bins=bins, color=C["hot"], alpha=0.60, lw=0.5, hatch="///",
            edgecolor=C["hot"], density=True, label="$S < S_c$")
    ax.set_xlim(-40, 110)
    ax.set_xlabel("elevation above median (m)")
    ax.set_ylabel("probability density")
    ax.legend(loc="upper right", handlelength=1.1)
    panel(ax, "a", x=-0.36)

    ax = axs[1]
    ax.bar(np.arange(len(seeds)), dEta, color=C["orange"], width=0.62)
    ax.axhline(np.mean(dEta), color="k", ls=(0, (4, 2)), lw=1.0)
    ax.text(len(seeds) - 0.4, np.mean(dEta) * 1.06,
            f"mean {np.mean(dEta):.0f} m", fontsize=7.0, ha="right")
    ax.set_xticks(np.arange(len(seeds)))
    ax.set_xticklabels([str(s) for s in seeds])
    ax.set_xlabel("structural realisation")
    ax.set_ylabel("$\\Delta\\eta$, sub-threshold minus\nsupra-threshold (m)")
    panel(ax, "b", x=-0.40)

    ax = axs[2]
    rng = np.random.default_rng(5)
    ix = rng.choice(len(allS), 500, replace=False)
    ax.scatter(allS[ix], allE[ix], s=2.2, alpha=0.35, color="#4a4a4a", lw=0)
    q = np.linspace(0.15, 2.8, 24)
    mids, lo, hi, md = [], [], [], []
    for k in range(len(q) - 1):
        mk = (allS >= q[k]) & (allS < q[k + 1])
        if mk.sum() >= 20:
            mids.append(0.5 * (q[k] + q[k + 1]))
            a_, b_, c_ = np.percentile(allE[mk], [10, 50, 90]); lo.append(a_); md.append(b_); hi.append(c_)
    ax.fill_between(mids, lo, hi, color="#d9d9d9", lw=0, zorder=0)
    ax.plot(mids, md, color=C["green"], lw=1.6)
    ax.axvline(Sc, color=C["hot"], lw=1.1, ls=(0, (4, 2)))
    ax.text(0.97, 0.95, f"$r$ = {np.mean(rr):.2f} $\\pm$ {np.std(rr):.2f}".replace("-", "\u2212"),
            transform=ax.transAxes, fontsize=7.4, va="top", ha="right")
    ax.text(Sc + 0.05, 0.05, "$S_c$", color=C["hot"], fontsize=7.6,
            transform=ax.get_xaxis_transform(), va="bottom", ha="left")
    ax.set_xlabel("structural index $S$")
    ax.set_ylabel("elevation above median (m)")
    ax.set_xlim(0.15, 2.8)
    panel(ax, "c", x=-0.34)

    save(fig, "fig06_structural_control")


# =============================================================================
# Figure 7  Sensitivity
# =============================================================================
def fig7():
    s = json.load(open(f"{RES}/sensitivity.json"))
    ex = json.load(open(f"{RES}/sensitivity_extra.json"))
    agg = {}
    for r in s["rows"] + ex:
        agg.setdefault(r["param"], {})[r["factor"]] = r

    labels = {"U": "$U$", "alpha": r"$\alpha$", "beta": r"$\beta$", "W0": "$W_0$",
              "Da0": "$Da_0$", "Hstar": "$H_*$", "D": "$D$", "Sc": "$G_c$",
              "eps": r"$\varepsilon$", "Ht": "$H_t$"}
    # threshold parameters (enter Eq. 12), equilibrium-only, surface/transport
    grp = {"U": "w", "alpha": "w", "beta": "w", "W0": "w", "Da0": "w",
           "Hstar": "e", "D": "t", "Sc": "t", "eps": "t", "Ht": "t"}
    colr = {"w": C["hot"], "e": C["mid"], "t": C["cool"]}
    hatch = {"w": "", "e": "////", "t": "...."}

    def index(par, key):
        lo, hi = agg[par][0.5][key], agg[par][2.0][key]
        lo = max(lo, 1e-6); hi = max(hi, 1e-6)
        return abs(np.log(hi / lo) / np.log(4.0))

    fig, axs = plt.subplots(1, 2, figsize=(COL2, 3.0))
    fig.subplots_adjust(wspace=0.55)
    for ax, key, ttl in [(axs[0], "relief", "relief"),
                         (axs[1], "meanH", "mean mantle thickness")]:
        vals = {p: index(p, key) for p in agg}
        order = sorted(vals, key=vals.get)
        y = np.arange(len(order))
        ax.barh(y, [max(vals[p], 0.0015) for p in order],
                color=[colr[grp[p]] for p in order], height=0.66,
                hatch=None, edgecolor="k", linewidth=0.5)
        for b, p in zip(ax.patches, order):
            b.set_hatch(hatch[grp[p]])
        ax.set_yticks(y)
        ax.set_yticklabels([labels[p] for p in order])
        ax.set_xlabel("$|\\,\\partial \\ln$ " + ttl + "$\\,/\\,\\partial \\ln p\\,|$")
        ax.set_title(ttl, fontsize=8.2, pad=4)
        for k, p in enumerate(order):
            ax.text(max(vals[p], 0.0015) + 0.045, k, ("<0.001" if vals[p] < 0.0005 else (f"{vals[p]:.3f}" if vals[p] < 0.1 else f"{vals[p]:.2f}")),
                    va="center", fontsize=6.8)
        ax.set_xlim(0, max(vals.values()) * 1.30)
    handles = [Rectangle((0, 0), 1, 1, fc=colr[k], ec="k", lw=0.5, hatch=hatch[k])
               for k in ("w", "e", "t")]
    axs[0].legend(handles, ["enters threshold (Eq. 12)", "equilibrium thickness only",
                            "surface / transport"],
                  loc="lower right", handlelength=1.2, fontsize=6.6)
    panel(axs[0], "a", x=-0.26)
    panel(axs[1], "b", x=-0.26)
    save(fig, "fig07_sensitivity")


if __name__ == "__main__":
    import sys
    todo = sys.argv[1:] or ["1", "2", "3", "4", "5", "6", "7"]
    for t in todo:
        globals()[f"fig{t}"]()
