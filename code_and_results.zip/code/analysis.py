"""Print every number quoted in the manuscript, computed from cached results."""
import json, os
import numpy as np
import model as m

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
i = slice(3, -3)


def main2d():
    d = np.load(f"{RES}/main2d.npz")
    S, H, eta, Heq = d["S"][i, i], d["H"][i, i], d["eta"][i, i], d["Heq"][i, i]
    Sc, dx = float(d["Sc"]), float(d["dx"])
    below = S < Sc
    print("== main 2D (interior)")
    print(f"S range {S.min():.2f}-{S.max():.2f}; mean {S.mean():.3f}; median {np.median(S):.3f}; "
          f"frac<Sc {100*below.mean():.1f}% ({below.sum()} of {S.size} cells)")
    print(f"H range {H.min():.1f}-{H.max():.1f}; mean {H.mean():.1f}")
    r = np.corrcoef(H.ravel(), Heq.ravel())[0, 1]
    rmse = np.sqrt(np.mean((H - Heq) ** 2))
    print(f"r(H,Heq)={r:.4f}; RMSE={rmse:.2f} m; mean bias={np.mean(H-Heq):.2f} m")
    sl = np.polyfit(Heq.ravel(), H.ravel(), 1)
    print(f"regression H = {sl[0]:.3f} Heq + {sl[1]:.2f}")
    sup = ~below
    print(f"supra only r={np.corrcoef(H[sup], Heq[sup])[0,1]:.4f} "
          f"RMSE={np.sqrt(np.mean((H[sup]-Heq[sup])**2)):.2f}")
    print(f"sub-threshold cells: mean H={H[below].mean():.2f} max H={H[below].max():.2f}")
    print(f"eta: sub {eta[below].mean():.1f}  supra {eta[~below].mean():.1f}  diff {eta[below].mean()-eta[~below].mean():.1f}")
    print(f"relief {eta.max()-eta.min():.1f}; max eta {eta.max():.1f}; min {eta.min():.1f}")
    q = np.percentile(eta, 90)
    top = eta >= q
    print(f"upper decile: mean S {S[top].mean():.2f}; frac cells sub-threshold {100*below[top].mean():.0f}%; "
          f"mean H {H[top].mean():.1f}; share of sub-thr cells in decile {100*(top&below).sum()/below.sum():.0f}%")
    print(f"mean elevation of upper-decile sub-threshold {eta[top&below].mean():.1f}")
    gy, gx = np.gradient(d["eta"], dx)
    sl_ = np.hypot(gx, gy)[i, i]
    print(f"slope: max {sl_.max():.3f}  p99 {np.percentile(sl_,99):.3f}  Sc 0.80; "
          f"frac>0.7 {100*(sl_>0.7).mean():.2f}%  max ratio {sl_.max()/0.8:.3f}")
    h = d["hist"]
    t, mh, rel = h[:, 0] / 1e6, h[:, 1], h[:, 2]
    fin = mh[-1]
    for frac in (0.9, 0.95):
        k = np.argmax(mh >= frac * fin)
        print(f"mean H reaches {int(frac*100)}% of final ({fin:.1f}) at {t[k]:.0f} Myr")
    for tt in (20, 40, 60, 80, 100, 120):
        k = np.argmin(abs(t - tt))
        print(f"  t={t[k]:5.1f} Myr meanH={mh[k]:.1f} relief={rel[k]:.1f}")
    # relief growth rate in last 40 Myr
    k0 = np.argmin(abs(t - 80))
    print(f"relief growth 80-120 Myr: {(rel[-1]-rel[k0])/(t[-1]-t[k0]):.2f} m/Myr")
    # expected rise of fully bare patch
    p = m.Params(W0=30e-6, Da0=1, Hstar=4, alpha=1.5, beta=1.0, eps=0.1, D=0.05,
                 Sc=0.8, Ht=0.5, U=3e-6)
    for s in (0.15, 0.22, 0.287):
        print(f"  W(H=0,S={s}) = {m.W_rate(0, s, p)*1e6:.2f} m/Myr  -> U-W = {(p.U-m.W_rate(0,s,p))*1e6:.2f}")


def structuretest():
    d = np.load(f"{RES}/structuretest.npz")
    Sc = float(d["Sc"])
    dEta, rr, fb = [], [], []
    print("== structure test")
    for s in d["seeds"]:
        S, H, e = d[f"S_{s}"], d[f"H_{s}"], d[f"eta_{s}"]
        e0 = e - np.median(e)
        b = S < Sc
        dEta.append(e0[b].mean() - e0[~b].mean())
        rr.append(np.corrcoef(e0.ravel(), S.ravel())[0, 1])
        fb.append(b.mean())
        print(f" seed {s}: frac<Sc {100*b.mean():.1f}%  d_eta {dEta[-1]:.1f}  r {rr[-1]:.3f} "
              f"relief {e.max()-e.min():.1f}")
    print(f" d_eta {np.mean(dEta):.1f} +- {np.std(dEta):.1f} (sd, ddof0) / {np.std(dEta, ddof=1):.1f} (ddof1)")
    print(f" r {np.mean(rr):.3f} +- {np.std(rr):.3f} / {np.std(rr, ddof=1):.3f}")


def sensitivity():
    s = json.load(open(f"{RES}/sensitivity.json"))
    ex = json.load(open(f"{RES}/sensitivity_extra.json")) if os.path.exists(
        f"{RES}/sensitivity_extra.json") else []
    agg = {}
    for r in s["rows"] + ex:
        agg.setdefault(r["param"], {})[r["factor"]] = r
    print("== sensitivity; base", s["base"])
    for p, v in agg.items():
        out = []
        for key in ("relief", "meanH"):
            lo, hi = max(v[0.5][key], 1e-6), max(v[2.0][key], 1e-6)
            out.append(f"{key}: {lo:.2f}->{hi:.2f} idx {abs(np.log(hi/lo)/np.log(4)):.3f}")
        print(f" {p:6s} " + " | ".join(out))


if __name__ == "__main__":
    for f in (main2d, structuretest, sensitivity):
        try:
            f()
        except Exception as e:
            print("skip", f.__name__, repr(e))


def patches():
    from scipy import ndimage
    d = np.load(f"{RES}/main2d.npz")
    S, eta = d["S"], d["eta"]
    Sc, dx = float(d["Sc"]), float(d["dx"])
    n = S.shape[0]
    ii, jj = np.indices(S.shape)
    inner = (ii >= 3) & (ii < n - 3) & (jj >= 3) & (jj < n - 3)
    dist = np.minimum(np.minimum(ii, n - 1 - ii), np.minimum(jj, n - 1 - jj)) * dx
    p = m.Params(W0=30e-6, Da0=1, Hstar=4, alpha=1.5, beta=1.0, eps=0.1, D=0.05,
                 Sc=0.8, Ht=0.5, U=3e-6)
    lab, nl = ndimage.label((S < Sc) & inner)
    rows = []
    for l in range(1, nl + 1):
        mk = lab == l
        ring = ndimage.binary_dilation(mk, iterations=3) & ~mk & inner & (S >= Sc)
        smin = S[mk].min()
        rate = (p.U - m.W_rate(0.0, smin, p)) * 1e6
        rows.append((l, int(mk.sum()), smin, rate, rate * 120, eta[mk].max() - eta[ring].mean(),
                     eta[mk].mean() - eta[ring].mean(), dist[mk].min()))
    print("== patches (id, cells, Smin, U-W0 [m/Myr], x120 Myr, peak excess, mean excess, min dist to edge)")
    for r in rows:
        print(" %d  %3d  %.2f  %.2f  %6.1f  %6.1f  %6.1f  %5.0f" % r)
    a = np.array(rows)
    from scipy.stats import spearmanr
    print(" spearman(peak excess, predicted):", spearmanr(a[:, 5], a[:, 4]))


if __name__ == "__main__" and False:
    pass
