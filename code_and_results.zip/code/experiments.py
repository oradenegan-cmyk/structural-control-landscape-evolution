"""Run every numerical experiment reported in the manuscript and cache results."""
import os, time, json
import numpy as np
import model as m

OUT = os.path.join(os.path.dirname(__file__), "results")
os.makedirs(OUT, exist_ok=True)

# ---- canonical configuration -------------------------------------------------
BASE = dict(W0=30.0e-6, Da0=1.0, Hstar=4.0, alpha=1.5, beta=1.0,
            eps=0.10, D=0.05, Sc=0.80, Ht=0.50, U=3.0e-6)
L2D, N2D, TEND = 2400.0, 81, 120e6
SFIELD = dict(corr_len=150.0, sigma=0.70, seed=7, lo=0.15, hi=3.0)


def make_S(n, dx, seed=None):
    s = dict(SFIELD)
    if seed is not None:
        s["seed"] = seed
    return np.clip(m.structural_field(n, dx, s["corr_len"], s["sigma"], s["seed"]),
                   s["lo"], s["hi"])


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


# =============================================================================
# 1. Verification: convergence of the numerical solution to the analytical
#    steady state, and the observed order of accuracy in time and space.
# =============================================================================
def exp_verification():
    """Three independent checks: order of accuracy in time, order of accuracy of
    the finite-volume divergence operator in space, and fidelity of the coupled
    solution to the closed-form steady state."""
    p = m.Params(**BASE)

    log("verification: temporal order of accuracy")
    _, Href, _ = m.run_0d(1.0, p, t_end=2.0e6, dt=5.0, H0=0.0)
    ref = Href[-1]
    dts = np.array([80000., 40000., 20000., 10000., 5000., 2500., 1250.])
    errs = np.array([abs(m.run_0d(1.0, p, t_end=2.0e6, dt=dt, H0=0.0)[1][-1] - ref)
                     for dt in dts])

    log("verification: spatial order of the divergence operator")
    # Manufactured solution.  eta = A*cos(kx)*cos(ky) on a doubly periodic patch;
    # transport is linearised (Sc -> infinity, H >> Ht) so div(qs) = -D*lap(eta)
    # has the exact value 2*D*A*k^2*cos(kx)*cos(ky).
    q = m.Params(**{**BASE, "Sc": 1e9, "Ht": 1e-9})
    A, kk, Lm = 20.0, 2 * np.pi / 600.0, 1200.0
    sp_dx, sp_err = [], []
    for n in [41, 81, 161, 321, 641]:
        x = np.linspace(0, Lm, n); dxx = x[1] - x[0]
        X, Y = np.meshgrid(x, x, indexing="xy")
        eta = A * np.cos(kk * X) * np.cos(kk * Y)
        Hf = np.full_like(eta, 50.0)
        num = m.flux_divergence(eta, Hf, q, dxx, dxx)
        exact = 2.0 * q.D * A * kk ** 2 * np.cos(kk * X) * np.cos(kk * Y)
        i = slice(4, -4)
        sp_dx.append(dxx)
        sp_err.append(np.sqrt(np.mean((num[i, i] - exact[i, i]) ** 2)))
    sp_dx, sp_err = np.array(sp_dx), np.array(sp_err)

    log("verification: coupled solution against closed-form steady state")
    Stest = np.array([0.35, 0.5, 0.75, 1.0, 1.5, 2.0, 2.5])
    num_H, ana_H = [], []
    for S in Stest:
        r = m.run_1d(S, p, L=2400.0, n=81, t_end=150e6, record_every=10**9)
        i = slice(30, 51)
        num_H.append(r["H"][i].mean())
        ana_H.append(m.H_eq(S, p))
        log(f"   S={S:4.2f}  numeric {num_H[-1]:7.2f}  analytic {ana_H[-1]:7.2f}")

    np.savez(f"{OUT}/verification.npz", dts=dts, errs=errs,
             sp_dx=sp_dx, sp_err=sp_err,
             Stest=Stest, num_H=np.array(num_H), ana_H=np.array(ana_H))
    log("verification done")


# =============================================================================
# 2. Analytical structure of the weathering law
# =============================================================================
def exp_analytical():
    log("analytical surfaces")
    p = m.Params(**BASE)
    H = np.linspace(0, 120, 400)
    Svals = np.array([0.3, 0.5, 1.0, 1.5, 2.5])
    Wcurves = np.array([m.W_rate(H, S, p) for S in Svals])
    Dacurves = np.array([m.damkohler(H, S, p) for S in Svals])

    Sg = np.linspace(0.12, 3.0, 500)
    Heq = m.H_eq(Sg, p)
    Sc = m.S_crit(p)

    # regime diagram: stripped vs mantled in (S, U/W0)
    ratio = np.logspace(-2.3, 0.0, 260)          # U/W0
    Sgrid = np.linspace(0.12, 3.0, 260)
    Z = np.zeros((ratio.size, Sgrid.size))
    for i, rr in enumerate(ratio):
        q = m.Params(**{**BASE, "U": rr * BASE["W0"]})
        Z[i, :] = m.H_eq(Sgrid, q)
    Sc_line = []
    for rr in ratio:
        q = m.Params(**{**BASE, "U": rr * BASE["W0"]})
        Sc_line.append(m.S_crit(q))

    # Damkohler sensitivity of the threshold
    Da_list = np.array([0.2, 0.5, 1.0, 2.0, 5.0])
    Sc_vs_Da = []
    for Da in Da_list:
        q = m.Params(**{**BASE, "Da0": Da})
        Sc_vs_Da.append(m.S_crit(q))

    np.savez(f"{OUT}/analytical.npz", H=H, Svals=Svals, Wcurves=Wcurves,
             Dacurves=Dacurves, Sg=Sg, Heq=Heq, Sc=Sc, ratio=ratio,
             Sgrid=Sgrid, Z=Z, Sc_line=np.array(Sc_line),
             Da_list=Da_list, Sc_vs_Da=np.array(Sc_vs_Da))
    log("analytical done")


# =============================================================================
# 3. Transient point-model trajectories (three structural regimes)
# =============================================================================
def exp_transient():
    log("transient trajectories")
    p = m.Params(**BASE)
    out = {}
    for name, S in [("stripped", 0.22), ("marginal", 0.40), ("mantled", 1.30)]:
        t, H, W = m.run_0d(S, p, t_end=120e6, dt=4000.0, H0=0.0)
        k = max(1, len(t) // 2000)
        out[f"t_{name}"] = t[::k]
        out[f"H_{name}"] = H[::k]
        out[f"W_{name}"] = W[::k]
        out[f"S_{name}"] = S
    np.savez(f"{OUT}/transient.npz", **out)
    log("transient done")


# =============================================================================
# 4. Main 2D simulation
# =============================================================================
def exp_main2d(chunk_myr=30.0):
    """Advance the main 2D simulation by one chunk, resuming from checkpoint."""
    p = m.Params(**BASE)
    dx = L2D / (N2D - 1)
    S = make_S(N2D, dx)
    ck = f"{OUT}/main2d_ck.npz"
    if os.path.exists(ck):
        d = np.load(ck)
        state = dict(H=d["H"], zw=d["zw"])
        t0 = float(d["t"]); hist = list(d["hist"])
        snaps = {float(k): dict(eta=e, H=h) for k, e, h in
                 zip(d["snap_times"], d["snap_eta"], d["snap_H"])}
    else:
        state, t0, hist, snaps = None, 0.0, [], {}
    dur = min(chunk_myr * 1e6, TEND - t0)
    if dur <= 0:
        log("main2d already complete"); return True
    log(f"main 2D: {t0/1e6:.0f} -> {(t0+dur)/1e6:.0f} Myr")
    tt = time.time()
    r = m.run_2d(S, p, L=L2D, t_end=dur, safety=0.55, state=state, t0=t0,
                 snapshots=(5e6, 20e6, 60e6), progress=True)
    log(f"  chunk took {time.time()-tt:.0f} s (dt={r['dt']:.0f} yr)")
    hist = hist + list(r["hist"])
    snaps.update({float(k): v for k, v in r["snaps"].items()})
    keys = sorted(snaps)
    np.savez(ck, H=r["H"], zw=r["zw"], t=t0 + dur, hist=np.array(hist),
             snap_times=np.array(keys),
             snap_eta=np.array([snaps[k]["eta"] for k in keys]),
             snap_H=np.array([snaps[k]["H"] for k in keys]))
    done = (t0 + dur) >= TEND - 1
    if done:
        np.savez(f"{OUT}/main2d.npz", S=S, H=r["H"], eta=r["eta"], zw=r["zw"],
                 dx=r["dx"], dt=r["dt"], hist=np.array(hist), L=L2D, tend=TEND,
                 Heq=m.H_eq(S, p), Sc=m.S_crit(p),
                 snap_times=np.array(keys),
                 snap_eta=np.array([snaps[k]["eta"] for k in keys]),
                 snap_H=np.array([snaps[k]["H"] for k in keys]))
        log("main 2D COMPLETE")
    return done


# =============================================================================
# 5. Sensitivity analysis (2D, one factor at a time, normalised indices)
# =============================================================================
def exp_sensitivity(budget=6):
    """One-factor-at-a-time 2D sensitivity, resumable; `budget` runs per call."""
    n, L, tend = 41, 1200.0, 45e6
    dx = L / (n - 1)
    S = make_S(n, dx)
    names = ["W0", "Da0", "Hstar", "alpha", "D", "U", "Sc", "eps"]
    factors = [0.5, 2.0]
    path = f"{OUT}/sensitivity.json"
    store = json.load(open(path)) if os.path.exists(path) else \
        dict(base=None, rows=[], names=names)

    def metrics(res):
        i = slice(3, -3)
        H, e = res["H"][i, i], res["eta"][i, i]
        return dict(meanH=float(H.mean()), relief=float(e.max() - e.min()),
                    stripped=float((H < 1.0).mean()),
                    p95H=float(np.percentile(H, 95)))

    todo = []
    if store["base"] is None:
        todo.append((None, None))
    have = {(r["param"], r["factor"]) for r in store["rows"]}
    for nm in names:
        for f in factors:
            if (nm, f) not in have:
                todo.append((nm, f))
    if not todo:
        log("sensitivity COMPLETE"); return True
    for nm, f in todo[:budget]:
        q = dict(BASE)
        if nm is not None:
            q[nm] = BASE[nm] * f
        r = m.run_2d(S, m.Params(**q), L=L, t_end=tend, safety=0.55)
        mm = metrics(r)
        if nm is None:
            store["base"] = mm
            log(f"  base: relief={mm['relief']:.1f} meanH={mm['meanH']:.1f}")
        else:
            store["rows"].append(dict(param=nm, factor=f, **mm))
            log(f"  {nm} x{f}: relief={mm['relief']:.1f} meanH={mm['meanH']:.1f} "
                f"stripped={mm['stripped']:.3f}")
        json.dump(store, open(path, "w"), indent=1)
    return len(todo) <= budget


# =============================================================================
# 6. Structural control test: does relief actually track S, and does the
#    predicted threshold locate the residual hills?
# =============================================================================
def exp_structuretest(budget=2):
    p = m.Params(**BASE)
    n, L, tend = 51, 1500.0, 50e6
    seeds = [7, 11, 23, 41, 57]
    path = f"{OUT}/structuretest.npz"
    store = dict(np.load(path)) if os.path.exists(path) else {}
    todo = [s for s in seeds if f"S_{s}" not in store]
    if not todo:
        log("structure test COMPLETE"); return True
    for sd in todo[:budget]:
        S = make_S(n, L / (n - 1), seed=sd)
        r = m.run_2d(S, p, L=L, t_end=tend, safety=0.55)
        i = slice(3, -3)
        store[f"S_{sd}"] = S[i, i]
        store[f"H_{sd}"] = r["H"][i, i]
        store[f"eta_{sd}"] = r["eta"][i, i]
        log(f"  seed {sd} done")
    store["Sc"] = m.S_crit(p)
    store["seeds"] = np.array(seeds)
    np.savez(path, **store)
    return len(todo) <= budget


if __name__ == "__main__":
    import sys
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    jobs = dict(verification=exp_verification, analytical=exp_analytical,
                transient=exp_transient, main2d=exp_main2d,
                sensitivity=exp_sensitivity, structuretest=exp_structuretest)
    jobs[which]()
