"""Additional experiments added during manuscript revision.

  nulltests    : uniform-structure and spatially shuffled-structure controls, and
                 a test of the surface mass-balance coefficient (eps = 0, 0.1, 1)
  sens_extra   : one-factor sensitivity for beta and H_t (omitted from the first
                 sensitivity set although beta enters the threshold condition)
  convergence  : halving of the time step and of the grid spacing
"""
import os, json, time
import numpy as np
import model as m
from experiments import BASE, OUT, make_S, log


def interior_metrics(res, S, Sc):
    i = slice(3, -3)
    H, e, s = res["H"][i, i], res["eta"][i, i], S[i, i]
    below = s < Sc
    gy, gx = np.gradient(res["eta"], res["dx"])
    slope = np.hypot(gx, gy)[i, i]
    out = dict(meanH=float(H.mean()), relief=float(e.max() - e.min()),
               maxslope=float(slope.max()),
               frac_below=float(below.mean()),
               corr_eta_S=float(np.corrcoef(e.ravel(), s.ravel())[0, 1]))
    if below.any() and (~below).any():
        out["d_eta"] = float(e[below].mean() - e[~below].mean())
    else:
        out["d_eta"] = float("nan")
    return out


def exp_nulltests():
    p = m.Params(**BASE)
    Sc = m.S_crit(p)
    n, L, tend = 51, 1500.0, 50e6
    dx = L / (n - 1)
    S7 = make_S(n, dx, seed=7)
    rng = np.random.default_rng(0)
    Ssh = S7.ravel().copy()
    rng.shuffle(Ssh)
    Ssh = Ssh.reshape(S7.shape)
    cases = {
        "structured_seed7_eps0.1": (S7, BASE),
        "uniform_S1": (np.ones_like(S7), BASE),
        "shuffled_seed7": (Ssh, BASE),
        "structured_eps0": (S7, {**BASE, "eps": 0.0}),
        "structured_eps1": (S7, {**BASE, "eps": 1.0}),
    }
    path = f"{OUT}/nulltests.json"
    store = json.load(open(path)) if os.path.exists(path) else {}
    for name, (S, par) in cases.items():
        if name in store:
            continue
        r = m.run_2d(S, m.Params(**par), L=L, t_end=tend, safety=0.55)
        store[name] = interior_metrics(r, S, Sc)
        log(f"{name}: {store[name]}")
        json.dump(store, open(path, "w"), indent=1)


def exp_sens_extra():
    n, L, tend = 41, 1200.0, 45e6
    dx = L / (n - 1)
    S = make_S(n, dx)
    path = f"{OUT}/sensitivity_extra.json"
    store = json.load(open(path)) if os.path.exists(path) else []
    have = {(r["param"], r["factor"]) for r in store}
    for nm in ["beta", "Ht"]:
        for f in [0.5, 2.0]:
            if (nm, f) in have:
                continue
            q = dict(BASE)
            q[nm] = BASE[nm] * f
            r = m.run_2d(S, m.Params(**q), L=L, t_end=tend, safety=0.55)
            i = slice(3, -3)
            H, e = r["H"][i, i], r["eta"][i, i]
            row = dict(param=nm, factor=f, meanH=float(H.mean()),
                       relief=float(e.max() - e.min()),
                       stripped=float((H < 1.0).mean()),
                       Sc=float(m.S_crit(m.Params(**q))))
            store.append(row)
            log(f"{nm} x{f}: {row}")
            json.dump(store, open(path, "w"), indent=1)


def exp_convergence():
    """Halve dt and dx on a reduced configuration (1.2 km, 30 Myr)."""
    p = m.Params(**BASE)
    L, tend = 1200.0, 30e6
    out = {}
    path = f"{OUT}/convergence.json"
    if os.path.exists(path):
        out = json.load(open(path))
    fine = make_S(81, L / 80, seed=7)
    from scipy.ndimage import zoom
    # a single structural field sampled on both grids (nearest block mean)
    base = fine[::2, ::2]
    runs = {
        "ref_n41_s0.55": (base, 0.55),
        "half_dt_n41": (base, 0.275),
        "half_dx_n81": (fine, 0.55),
    }
    for name, (S, saf) in runs.items():
        if name in out:
            continue
        r = m.run_2d(S, p, L=L, t_end=tend, safety=saf)
        i = slice(3, -3) if S.shape[0] == 41 else slice(6, -6)
        H, e = r["H"][i, i], r["eta"][i, i]
        out[name] = dict(meanH=float(H.mean()), relief=float(e.max() - e.min()),
                         mean_eta=float(e.mean()), dt=float(r["dt"]))
        log(f"{name}: {out[name]}")
        json.dump(out, open(path, "w"), indent=1)


def exp_sens_metrics(names=("D", "Sc", "Ht", "U")):
    """Robust relief metrics (not the extreme max-min) for transport parameters.
    Max-min relief is set by the lowest-S cell, whose elevation is the integrated
    front deficit and is independent of hillslope transport by construction."""
    n, L, tend = 41, 1200.0, 45e6
    dx = L / (n - 1)
    S = make_S(n, dx)
    Sc0 = m.S_crit(m.Params(**BASE))
    path = f"{OUT}/sens_metrics{os.environ.get('SMTAG', '')}.json"
    store = json.load(open(path)) if os.path.exists(path) else []
    have = {(r["param"], r["factor"]) for r in store}
    jobs = [(None, 1.0)] + [(nm, f) for nm in names for f in (0.5, 2.0)]
    for nm, f in jobs:
        if (str(nm), f) in have:
            continue
        q = dict(BASE)
        if nm is not None:
            q[nm] = BASE[nm] * f
        par = m.Params(**q)
        r = m.run_2d(S, par, L=L, t_end=tend, safety=0.55)
        i = slice(3, -3)
        e, s = r["eta"][i, i], S[i, i]
        sc = m.S_crit(par)
        b = s < sc
        row = dict(param=str(nm), factor=f, p95_p5=float(np.percentile(e, 95) - np.percentile(e, 5)),
                   std=float(e.std()), mean_eta=float(e.mean()), max=float(e.max()),
                   d_eta=float(e[b].mean() - e[~b].mean()) if b.any() else float("nan"),
                   frac_below=float(b.mean()))
        store.append(row)
        log(f"{nm} x{f}: {row}")
        json.dump(store, open(path, "w"), indent=1)


if __name__ == "__main__":
    import sys
    {"nulltests": exp_nulltests, "sens_extra": exp_sens_extra,
     "convergence": exp_convergence, "sens_metrics": exp_sens_metrics}[sys.argv[1]](*([tuple(sys.argv[2].split(","))] if len(sys.argv) > 2 else []))
