"""
Coupled weathering-front / surface evolution model for crystalline basement terrain.

Corrected formulation
---------------------
Interfaces:  eta(x,y,t)  land surface
             zw(x,y,t)   weathering front
             H = eta - zw  thickness of the weathered mantle

Kinematics (U = rock uplift relative to base level, W = front propagation rate):

    d(zw)/dt  = U - W
    d(H)/dt   = (1 + eps) * W - div(qs)
    eta       = zw + H,      H >= 0

eps is the dilation coefficient, eps = chi*rho_r/rho_s - 1, i.e. the EXTRA column
thickness produced per unit thickness of rock consumed.  For isovolumetric
saprolitisation eps -> 0.  Note the surface consequence:

    d(eta)/dt = U + eps*W - div(qs)

so weathering contributes eps*W (order 0.1 W), not W, to surface elevation.

Weathering law (resistances in series, reaction control + transport control):

    1/W = 1/W_R + 1/W_T
    W_R = W0 * S**alpha                          (reaction / surface-area limited)
    W_T = W0 * S**beta / (Da0 * (1 + H/Hstar))   (solute-transport limited)

  =>  W(H,S) = W0 * S**alpha / (1 + Da(H,S))
      Da(H,S) = Da0 * S**(alpha-beta) * (1 + H/Hstar)     [local Damkohler number]

Transport (nonlinear, supply-limited):

    qs = -D * grad(eta) / (1 - (|grad eta|/Sc)**2) * (1 - exp(-H/Ht))
"""

import numpy as np


# --------------------------------------------------------------------------
# Parameters
# --------------------------------------------------------------------------
class Params:
    def __init__(self, **kw):
        self.W0    = 30.0e-6   # m/yr   reaction-limited bare-rock front velocity
        self.Da0   = 1.0       # -      reference Damkohler number
        self.Hstar = 4.0       # m      transport attenuation length
        self.alpha = 1.5       # -      structural exponent, reaction control
        self.beta  = 1.0       # -      structural exponent, transport control
        self.eps   = 0.10      # -      dilation coefficient
        self.D     = 0.02      # m^2/yr hillslope transport coefficient
        self.Sc    = 0.80      # m/m    critical gradient
        self.Ht    = 0.50      # m      transport shutdown depth
        self.U     = 3.0e-6    # m/yr   rock uplift rate
        for k, v in kw.items():
            if not hasattr(self, k):
                raise KeyError(k)
            setattr(self, k, v)


# --------------------------------------------------------------------------
# Weathering law and its analytical consequences
# --------------------------------------------------------------------------
def damkohler(H, S, p):
    return p.Da0 * S ** (p.alpha - p.beta) * (1.0 + H / p.Hstar)


def W_rate(H, S, p):
    return p.W0 * S ** p.alpha / (1.0 + damkohler(H, S, p))


def H_eq(S, p):
    """Analytical equilibrium mantle thickness where W = U.

    Returns 0 where no mantled steady state exists (stripped domain)."""
    S = np.asarray(S, dtype=float)
    num = p.W0 * S ** p.alpha / p.U - 1.0
    den = p.Da0 * S ** (p.alpha - p.beta)
    H = p.Hstar * (num / den - 1.0)
    return np.maximum(H, 0.0)


def S_crit(p):
    """Critical structural index below which no mantled steady state exists.

    Solves  W0 * S**alpha = U * (1 + Da0 * S**(alpha-beta)).
    Closed form when alpha == beta; otherwise solved by bisection."""
    if abs(p.alpha - p.beta) < 1e-12:
        return (p.U * (1.0 + p.Da0) / p.W0) ** (1.0 / p.alpha)
    f = lambda S: p.W0 * S ** p.alpha - p.U * (1.0 + p.Da0 * S ** (p.alpha - p.beta))
    lo, hi = 1e-6, 1e3
    if f(hi) < 0:
        return np.inf
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if f(mid) < 0:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


# --------------------------------------------------------------------------
# Numerics: gradients, flux divergence
# --------------------------------------------------------------------------
def _slope_mag(eta, dx, dy):
    gy, gx = np.gradient(eta, dy, dx)
    return gx, gy, np.sqrt(gx ** 2 + gy ** 2)


def flux_divergence(eta, H, p, dx, dy, slope_cap=0.95):
    """div(qs) by a face-centred finite-volume evaluation.

    Fluxes are formed on cell faces from compact two-point gradients, so the
    divergence uses a compact stencil and does not admit the odd-even decoupling
    that a gradient-of-a-gradient (np.gradient twice) stencil supports.
    """
    ep = np.pad(eta, 1, mode="edge")
    Hp = np.pad(H, 1, mode="edge")

    # face-normal gradients: x-faces have shape (n, n+1); y-faces (n+1, n)
    gx_f = (ep[1:-1, 1:] - ep[1:-1, :-1]) / dx
    gy_f = (ep[1:, 1:-1] - ep[:-1, 1:-1]) / dy

    # transverse component averaged onto each face set
    gy_c = (ep[2:, 1:-1] - ep[:-2, 1:-1]) / (2 * dy)          # (n, n)
    gy_cp = np.pad(gy_c, ((0, 0), (1, 1)), mode="edge")
    gy_on_x = 0.5 * (gy_cp[:, 1:] + gy_cp[:, :-1])

    gx_c = (ep[1:-1, 2:] - ep[1:-1, :-2]) / (2 * dx)
    gx_cp = np.pad(gx_c, ((1, 1), (0, 0)), mode="edge")
    gx_on_y = 0.5 * (gx_cp[1:, :] + gx_cp[:-1, :])

    sm_x = np.hypot(gx_f, gy_on_x)
    sm_y = np.hypot(gx_on_y, gy_f)

    Hx = 0.5 * (Hp[1:-1, 1:] + Hp[1:-1, :-1])
    Hy = 0.5 * (Hp[1:, 1:-1] + Hp[:-1, 1:-1])

    def k_of(sm, Hf):
        r = np.minimum(sm / p.Sc, slope_cap)
        return p.D / (1.0 - r ** 2) * (1.0 - np.exp(-Hf / p.Ht))

    qx = -k_of(sm_x, Hx) * gx_f
    qy = -k_of(sm_y, Hy) * gy_f
    return (qx[:, 1:] - qx[:, :-1]) / dx + (qy[1:, :] - qy[:-1, :]) / dy


def max_effective_D(p, slope_cap=0.95):
    return p.D / (1.0 - slope_cap ** 2)


# --------------------------------------------------------------------------
# 1D solver (used for verification and transient experiments)
# --------------------------------------------------------------------------
def run_1d(S, p, L=3000.0, n=201, t_end=200e6, dt=None, H0=0.0,
           record_every=None, slope_cap=0.95):
    """Fixed-elevation (base level) boundaries at both ends."""
    dx = L / (n - 1)
    if dt is None:
        dt = 0.20 * dx ** 2 / (2.0 * max_effective_D(p, slope_cap))
    S = np.full(n, S, dtype=float) if np.isscalar(S) else np.asarray(S, float)
    H = np.full(n, float(H0))
    zw = np.zeros(n)
    eta = zw + H
    nsteps = int(round(t_end / dt))
    rec = []
    if record_every is None:
        record_every = max(1, nsteps // 200)

    for it in range(nsteps):
        W = W_rate(H, S, p)
        g = np.gradient(eta, dx)
        ratio = np.minimum(np.abs(g) / p.Sc, slope_cap)
        k = p.D / (1.0 - ratio ** 2) * (1.0 - np.exp(-H / p.Ht))
        q = -k * g
        div = np.gradient(q, dx)
        H = H + dt * ((1.0 + p.eps) * W - div)
        np.maximum(H, 0.0, out=H)
        zw = zw + dt * (p.U - W)
        eta = zw + H
        eta[0] = eta[-1] = 0.0
        zw[0] = eta[0] - H[0]
        zw[-1] = eta[-1] - H[-1]
        if it % record_every == 0:
            rec.append((it * dt, H.copy(), eta.copy(), zw.copy()))
    return dict(x=np.arange(n) * dx, H=H, eta=eta, zw=zw, dt=dt, rec=rec, S=S)


def run_0d(S, p, t_end=200e6, dt=2000.0, H0=0.0):
    """Point model: no transport, mantle removed at the rate required for
    topographic steady state.  Used to isolate the weathering feedback."""
    n = int(round(t_end / dt))
    H = float(H0)
    t = np.empty(n)
    Ht = np.empty(n)
    Wt = np.empty(n)
    for i in range(n):
        W = W_rate(H, S, p)
        E = p.U * (1.0 + p.eps)          # steady-state removal demand
        H = max(H + dt * ((1.0 + p.eps) * W - E), 0.0)
        t[i] = i * dt
        Ht[i] = H
        Wt[i] = W
    return t, Ht, Wt


# --------------------------------------------------------------------------
# 2D solver
# --------------------------------------------------------------------------
def structural_field(n, dx, corr_len=180.0, sigma=0.55, seed=7):
    """Log-normal, spatially correlated structural index with mean 1."""
    from scipy.ndimage import gaussian_filter
    rng = np.random.default_rng(seed)
    g = rng.standard_normal((n, n))
    g = gaussian_filter(g, sigma=corr_len / dx, mode="wrap")
    g = (g - g.mean()) / g.std()
    S = np.exp(sigma * g - 0.5 * sigma ** 2)
    return S


def run_2d(S, p, L=3000.0, t_end=150e6, dt=None, H0=0.0, slope_cap=0.95,
           snapshots=(), progress=False, safety=0.40, state=None, t0=0.0):
    """Explicit forward-Euler integration on a uniform square grid.

    Boundary treatment: the outer ring is a fixed-elevation sediment outlet.
    Elevation is pinned to base level and mantle thickness is set equal to the
    adjacent interior value, so material arriving at the margin leaves the
    domain instead of accumulating against a pinned surface.
    """
    n = S.shape[0]
    dx = dy = L / (n - 1)
    if dt is None:
        dt = safety * dx ** 2 / (4.0 * max_effective_D(p, slope_cap))
    if state is None:
        H = np.full((n, n), float(H0))
        zw = np.zeros((n, n))
    else:
        H = state["H"].copy()
        zw = state["zw"].copy()
    eta = zw + H
    nsteps = int(round(t_end / dt))
    snaps = {}
    snap_steps = {int(round((s - t0) / dt)): s for s in snapshots if s >= t0}
    hist = []

    def apply_bc(eta, H, zw):
        H[0, :] = H[1, :]; H[-1, :] = H[-2, :]
        H[:, 0] = H[:, 1]; H[:, -1] = H[:, -2]
        eta[0, :] = eta[-1, :] = 0.0
        eta[:, 0] = eta[:, -1] = 0.0
        zw[0, :] = eta[0, :] - H[0, :]
        zw[-1, :] = eta[-1, :] - H[-1, :]
        zw[:, 0] = eta[:, 0] - H[:, 0]
        zw[:, -1] = eta[:, -1] - H[:, -1]

    for it in range(nsteps):
        W = W_rate(H, S, p)
        div = flux_divergence(eta, H, p, dx, dy, slope_cap)
        H = H + dt * ((1.0 + p.eps) * W - div)
        np.maximum(H, 0.0, out=H)
        zw = zw + dt * (p.U - W)
        eta = zw + H
        apply_bc(eta, H, zw)
        if it % max(1, nsteps // 400) == 0:
            i = slice(3, -3)
            hist.append((t0 + it * dt, H[i, i].mean(),
                         eta[i, i].max() - eta[i, i].min()))
        if it in snap_steps:
            snaps[snap_steps[it]] = dict(H=H.copy(), eta=eta.copy(), zw=zw.copy())
        if progress and it % max(1, nsteps // 10) == 0:
            i = slice(3, -3)
            print(f"  {100*it/nsteps:5.1f}%  meanH={H[i,i].mean():7.2f}  "
                  f"relief={eta[i,i].max()-eta[i,i].min():7.2f}", flush=True)
    return dict(S=S, H=H, eta=eta, zw=zw, dx=dx, dt=dt, snaps=snaps,
                hist=np.array(hist))


def hillshade(eta, dx, az=315.0, alt=45.0, ve=3.0):
    gy, gx = np.gradient(eta * ve, dx, dx)
    slope = np.arctan(np.hypot(gx, gy))
    aspect = np.arctan2(-gx, gy)
    az_r, alt_r = np.radians(360.0 - az + 90.0), np.radians(alt)
    hs = (np.sin(alt_r) * np.cos(slope) +
          np.cos(alt_r) * np.sin(slope) * np.cos(az_r - aspect))
    return np.clip(hs, 0, 1)
