# Code and results: structural threshold for etchplanation

- code/model.py: coupled weathering-front and surface model
- code/experiments.py, experiments_extra.py: all simulations (extra = null tests, convergence, extra sensitivity, robust metrics)
- code/analysis.py: prints every number quoted in the manuscript from results/
- code/figures.py: draws Figures 1-7 (PNG/PDF/TIFF at 600 dpi), checks label overlaps and writes each figure as editable Word shapes (figures/shapes/*.xml) through code/shapes.py
- results/: simulation output; figures/: final figures

Requires Python 3 with numpy, scipy, matplotlib. Run the experiments, then analysis.py and figures.py. Insert the DOI of the archived copy in the manuscript Data availability statement.
